﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_BIBLIOTECA
{
    public class Leitor
    {
        private int CODIGO;

        public Leitor(int _cod)
        {
            CODIGO = _cod;
        }
    }
}
