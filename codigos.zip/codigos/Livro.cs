﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_BIBLIOTECA
{
    public class Livro
    {
        string ISBN;

        public Livro(string tit, string _isbn)
            
        {
            ISBN = _isbn;
        }
        
    }
}
